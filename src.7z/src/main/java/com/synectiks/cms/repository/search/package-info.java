/**
 * Spring Data Elasticsearch repositories.
 */
package com.synectiks.cms.repository.search;
