/**
 * Service layer beans.
 */
package com.synectiks.cms.service;
