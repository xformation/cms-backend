/**
 * Spring Security configuration.
 */
package com.synectiks.cms.security;
