import { $, browser, ElementFinder } from 'protractor';
import { promise } from 'selenium-webdriver';

import BasePage from './base-component';

const selector: ElementFinder = $('#settings-form');
export default class SettingsPage extends BasePage {
  selector: ElementFinder;
  firstName: ElementFinder = this.selector.$('#firstName');
  lastName: ElementFinder = this.selector.$('#lastName');
  email: ElementFinder = this.selector.$('#email');
  saveButton: ElementFinder = this.selector.$('button[type=submit]');
  title: ElementFinder = $('#settings-title');

  constructor() {
    super(selector);
    this.selector = selector;
  }

  get() {
    browser.get('#/account/settings');
    this.waitUntilDisplayed();
  }

  getTitle() {
    return this.title.getAttribute('id');
  }

  setFirstName(firstName) {
    return this.firstName.sendKeys(firstName);
  }

  setLastName(lastName) {
    return this.lastName.sendKeys(lastName);
  }

  setEmail(email) {
    return this.email.sendKeys(email);
  }

  clearEmail() {
    return this.email.clear();
  }

  save() {
    return this.saveButton.click();
  }
}
