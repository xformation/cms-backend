/* tslint:disable no-unused-expression */
import { browser } from 'protractor';

import NavBarPage from './../../page-objects/navbar-page';
import SubjectComponentsPage from './subject.page-object';
import SubjectUpdatePage from './subject-update.page-object';

const expect = chai.expect;

describe('Subject e2e test', () => {
  let navBarPage: NavBarPage;
  let subjectUpdatePage: SubjectUpdatePage;
  let subjectComponentsPage: SubjectComponentsPage;

  before(() => {
    browser.get('/');
    navBarPage = new NavBarPage();
    navBarPage.autoSignIn();
  });

  it('should load Subjects', async () => {
    navBarPage.getEntityPage('subject');
    subjectComponentsPage = new SubjectComponentsPage();
    expect(await subjectComponentsPage.getTitle().getText()).to.match(/Subjects/);
  });

  it('should load create Subject page', async () => {
    subjectComponentsPage.clickOnCreateButton();
    subjectUpdatePage = new SubjectUpdatePage();
    expect(await subjectUpdatePage.getPageTitle().getText()).to.match(/Create or edit a Subject/);
  });

  it('should create and save Subjects', async () => {
    subjectUpdatePage.setSubjectCodeInput('subjectCode');
    expect(await subjectUpdatePage.getSubjectCodeInput()).to.match(/subjectCode/);
    subjectUpdatePage.subjectTypeSelectLastOption();
    subjectUpdatePage.setSubjectDescInput('subjectDesc');
    expect(await subjectUpdatePage.getSubjectDescInput()).to.match(/subjectDesc/);
    subjectUpdatePage.statusSelectLastOption();
    subjectUpdatePage.departmentSelectLastOption();
    subjectUpdatePage.batchSelectLastOption();
    await subjectUpdatePage.save();
    expect(await subjectUpdatePage.getSaveButton().isPresent()).to.be.false;
  });

  after(() => {
    navBarPage.autoSignOut();
  });
});
