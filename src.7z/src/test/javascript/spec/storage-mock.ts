let StorageMock = () => {
  let store = {};
  return {
    getItem: (key: any) => store[key] || null,
    setItem: (key: any, value: any) => (store[key] = value.toString()),
    clear: () => (store = {})
  };
};

Object.defineProperty(window, 'localStorage', {
  value: StorageMock()
});

Object.defineProperty(window, 'sessionStorage', {
  value: StorageMock()
});
