/**
 * Spring Framework configuration files.
 */
package com.synectiks.cms.config;
