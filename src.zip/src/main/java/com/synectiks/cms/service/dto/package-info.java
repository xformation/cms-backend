/**
 * Data Transfer Objects.
 */
package com.synectiks.cms.service.dto;
