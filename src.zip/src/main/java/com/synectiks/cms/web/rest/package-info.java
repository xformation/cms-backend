/**
 * Spring MVC REST controllers.
 */
package com.synectiks.cms.web.rest;
