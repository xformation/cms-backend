package com.synectiks.cms.domain.enumeration;

/**
 * The BatchEnum enumeration.
 */
public enum BatchEnum {
    FIRSTYEAR, SECONDYEAR, THIRDYEAR, FOURTHYEAR
}
