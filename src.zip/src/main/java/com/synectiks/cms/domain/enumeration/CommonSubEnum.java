package com.synectiks.cms.domain.enumeration;

/**
 * The CommonSubEnum enumeration.
 */
public enum CommonSubEnum {
    MATHS, PHYSICS, CHEMISTRY, DBMS
}
