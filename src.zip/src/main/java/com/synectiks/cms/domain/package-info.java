/**
 * JPA domain objects.
 */
package com.synectiks.cms.domain;
