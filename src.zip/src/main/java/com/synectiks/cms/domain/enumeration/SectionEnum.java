package com.synectiks.cms.domain.enumeration;

/**
 * The SectionEnum enumeration.
 */
public enum SectionEnum {
    A, B, C, D
}
