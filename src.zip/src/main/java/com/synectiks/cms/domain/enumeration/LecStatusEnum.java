package com.synectiks.cms.domain.enumeration;

/**
 * The LecStatusEnum enumeration.
 */
public enum LecStatusEnum {
    ACTIVE, DEACTIVE, CANCELLED
}
