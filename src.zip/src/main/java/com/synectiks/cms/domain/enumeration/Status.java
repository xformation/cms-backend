package com.synectiks.cms.domain.enumeration;

/**
 * The Status enumeration.
 */
public enum Status {
    ACTIVE, DEACTIVE
}
