package com.synectiks.cms.domain.enumeration;

/**
 * The SubTypeEnum enumeration.
 */
public enum SubTypeEnum {
    COMMON, ELECTIVE
}
