package com.synectiks.cms.domain.enumeration;

/**
 * The TypeOfCollege enumeration.
 */
public enum TypeOfCollege {
    PRIVATE, PUBLIC
}
