package com.synectiks.cms.domain.enumeration;

/**
 * The ElectiveEnum enumeration.
 */
public enum ElectiveEnum {
    JAVA, C
}
