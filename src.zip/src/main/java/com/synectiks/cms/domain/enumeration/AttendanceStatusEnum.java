package com.synectiks.cms.domain.enumeration;

/**
 * The AttendanceStatusEnum enumeration.
 */
public enum AttendanceStatusEnum {
    PRESENT, ABSENT
}
