package com.synectiks.cms.domain.enumeration;

/**
 * The NameOfBank enumeration.
 */
public enum NameOfBank {
    HDFC, SBI, ICICI, ANDHRABANK
}
