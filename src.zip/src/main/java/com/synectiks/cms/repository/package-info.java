/**
 * Spring Data JPA repositories.
 */
package com.synectiks.cms.repository;
