package com.synectiks.cms.graphql.types.College;

public class UpdateCollegeInput extends AbstractCollegeInput {
}
