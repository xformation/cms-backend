package com.synectiks.cms.graphql.types.AttendanceMaster;

import com.synectiks.cms.domain.AttendanceMaster;

public class UpdateAttendanceMasterPayload extends AbstractAttendanceMasterPayload {
    public UpdateAttendanceMasterPayload(AttendanceMaster attendanceMaster) {
        super(attendanceMaster);
    }
}
