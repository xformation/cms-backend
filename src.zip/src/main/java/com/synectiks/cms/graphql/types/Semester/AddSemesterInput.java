//package com.synectiks.cms.graphql.types.Semester;
//
//public class AddSemesterInput extends AbstractSemesterInput{
//    @Override
//    public String toString() {
//        return "AddSemesterInput{}" + super.toString();
//    }
//}
