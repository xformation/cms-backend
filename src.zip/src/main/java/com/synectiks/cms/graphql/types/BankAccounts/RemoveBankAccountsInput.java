package com.synectiks.cms.graphql.types.BankAccounts;

public class RemoveBankAccountsInput {
    private Long bankAccountsId;

    public Long getBankAccountsId() {
        return bankAccountsId;
    }

    public void setBankAccountsId(Long bankAccountsId) {
        this.bankAccountsId = bankAccountsId;
    }
}
