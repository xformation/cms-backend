//package com.synectiks.cms.graphql.types.Semester;
//
//public class RemoveSemesterInput {
//    private Long semesterId;
//
//    public Long getSemesterId() {
//        return semesterId;
//    }
//
//    public void setSemesterId(Long semesterId) {
//        this.semesterId = semesterId;
//    }
//}
