//package com.synectiks.cms.graphql.types.StudentYear;
//
//import com.synectiks.cms.domain.StudentYear;
//
//import java.util.List;
//
//public class RemoveStudentYearPayload {
//    private final List<StudentYear> studentYears;
//
//    public RemoveStudentYearPayload(List<StudentYear> studentYears) {
//        this.studentYears = studentYears;
//    }
//
//    public List<StudentYear> getStudentYears() {
//        return studentYears;
//    }
//}
