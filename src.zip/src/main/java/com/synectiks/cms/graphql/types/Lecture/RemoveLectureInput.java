package com.synectiks.cms.graphql.types.Lecture;

public class RemoveLectureInput {
    private Long lectureId;

	public Long getLectureId() {
		return lectureId;
	}

	public void setLectureId(Long lectureId) {
		this.lectureId = lectureId;
	}

	

    
}
