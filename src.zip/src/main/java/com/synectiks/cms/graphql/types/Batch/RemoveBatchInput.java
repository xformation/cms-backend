package com.synectiks.cms.graphql.types.Batch;

public class RemoveBatchInput {
    private Long batchId;

	public Long getBatchId() {
		return batchId;
	}

	public void setBatchId(Long batchId) {
		this.batchId = batchId;
	}

	

    
}
