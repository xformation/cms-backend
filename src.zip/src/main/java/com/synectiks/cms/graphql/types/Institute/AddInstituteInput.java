package com.synectiks.cms.graphql.types.Institute;


public class AddInstituteInput  extends AbstractInstituteInput {
    @Override
    public String toString(){
        return "AddInstituteInput {}" +super.toString();
    }
}
