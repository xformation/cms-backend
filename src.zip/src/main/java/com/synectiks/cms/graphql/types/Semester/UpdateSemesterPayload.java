//package com.synectiks.cms.graphql.types.Semester;
//
//import com.synectiks.cms.domain.Semester;
//
//public class UpdateSemesterPayload extends AbstractSemesterPayload{
//    public UpdateSemesterPayload(Semester semester) {
//        super(semester);
//    }
//}
