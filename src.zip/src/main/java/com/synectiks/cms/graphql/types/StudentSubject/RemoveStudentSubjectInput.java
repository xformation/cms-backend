package com.synectiks.cms.graphql.types.StudentSubject;

public class RemoveStudentSubjectInput {
    private Long studentSubjectId;

    public Long getStudentSubjectId() {
        return studentSubjectId;
    }

    public void setStudentSubjectId(Long studentSubjectId) {
        this.studentSubjectId = studentSubjectId;
    }
}
