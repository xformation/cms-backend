package com.synectiks.cms.graphql.types.LegalEntity;

import com.synectiks.cms.domain.LegalEntity;

public class AddLegalEntityPayload extends AbstractLegalEntityPayload {
    public AddLegalEntityPayload(LegalEntity legalEntity) {
        super(legalEntity);
    }
}
