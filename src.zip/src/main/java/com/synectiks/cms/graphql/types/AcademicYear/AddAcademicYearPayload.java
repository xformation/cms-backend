package com.synectiks.cms.graphql.types.AcademicYear;

import com.synectiks.cms.domain.AcademicYear;

public class AddAcademicYearPayload extends AbstractAcademicYearPayload {
    public AddAcademicYearPayload(AcademicYear academicYear){
        super(academicYear);
    }
}
