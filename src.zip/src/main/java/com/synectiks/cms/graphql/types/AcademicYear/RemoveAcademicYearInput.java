package com.synectiks.cms.graphql.types.AcademicYear;

public class RemoveAcademicYearInput {
    private Long academicYearId;

    public Long getAcademicYearId() {
        return academicYearId;
    }

    public void setAcademicYearId(Long academicYearId) {
        this.academicYearId = academicYearId;
    }
}
