//package com.synectiks.cms.graphql.types.Semester;
//
//import com.synectiks.cms.domain.Semester;
//
//public class AbstractSemesterPayload {
//    private final Semester semester;
//
//    public AbstractSemesterPayload(Semester semester) {
//        this.semester = semester;
//    }
//
//    public Semester getSemester() {
//        return semester;
//    }
//}
