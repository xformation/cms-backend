package com.synectiks.cms.graphql.types.Teacher;

public class RemoveTeacherInput {
    private Long teacherId;

    public Long getTeacherId() {
        return teacherId;
    }

    public void setTeacherId(Long teacherId) {
        this.teacherId = teacherId;
    }
}
