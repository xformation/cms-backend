package com.synectiks.cms.graphql.types.AcademicYear;

public class UpdateAcademicYearInput extends AbstractAcademicYearInput {
}
