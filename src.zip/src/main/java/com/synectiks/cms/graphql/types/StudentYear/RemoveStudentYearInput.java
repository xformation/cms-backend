package com.synectiks.cms.graphql.types.StudentYear;

public class RemoveStudentYearInput {
    private Long studentYearId;

    public Long getStudentYearId() {
        return studentYearId;
    }

    public void setStudentYearId(Long studentYearId) {
        this.studentYearId = studentYearId;
    }
}
