//package com.synectiks.cms.graphql.types.Semester;
//
//public class UpdateSemesterInput extends AbstractSemesterInput{
//}
