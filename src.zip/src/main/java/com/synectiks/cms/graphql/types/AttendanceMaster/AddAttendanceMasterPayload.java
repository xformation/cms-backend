package com.synectiks.cms.graphql.types.AttendanceMaster;

import com.synectiks.cms.domain.AttendanceMaster;

public class AddAttendanceMasterPayload extends AbstractAttendanceMasterPayload {
    public AddAttendanceMasterPayload(AttendanceMaster attendanceMaster) {
        super(attendanceMaster);
    }
}
