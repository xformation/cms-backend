//package com.synectiks.cms.graphql.types.StudentYear;
//
//import com.synectiks.cms.domain.StudentYear;
//
//public class UpdateStudentYearPayload extends AbstractStudentYearPayload{
//    public UpdateStudentYearPayload(StudentYear studentYear) {
//        super(studentYear);
//    }
//}
