package com.synectiks.cms.graphql.types.Teach;

public class RemoveTeachInput {
    private Long teachId;

	public Long getTeachId() {
		return teachId;
	}

	public void setTeachId(Long teachId) {
		this.teachId = teachId;
	}


    
}
