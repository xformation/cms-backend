package com.synectiks.cms.graphql.types.Student;

public enum Gender {
    MALE, FEMALE, OTHER
}
