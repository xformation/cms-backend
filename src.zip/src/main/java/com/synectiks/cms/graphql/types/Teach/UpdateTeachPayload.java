package com.synectiks.cms.graphql.types.Teach;

import com.synectiks.cms.domain.Teach;

public class UpdateTeachPayload extends AbstractTeachPayload {
    public UpdateTeachPayload(Teach teach) {
        super(teach);
    }
}
