package com.synectiks.cms.graphql.types.Location;

public class AddLocationInput extends  AbstractLocationInput{
    @Override
    public String toString() {
        return "AddLocationInput{}" + super.toString();
    }
}
