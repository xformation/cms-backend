package com.synectiks.cms.graphql.types.StudentAttendance;

public class RemoveStudentAttendanceInput {
    private Long studentAttendanceId;

    public Long getStudentAttendanceId() {
        return studentAttendanceId;
    }

    public void setStudentAttendanceId(Long studentAttendanceId) {
        this.studentAttendanceId = studentAttendanceId;
    }
}
