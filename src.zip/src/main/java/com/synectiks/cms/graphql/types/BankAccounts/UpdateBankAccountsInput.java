package com.synectiks.cms.graphql.types.BankAccounts;

public class UpdateBankAccountsInput extends AbstractBankAccountsInput {
}
