package com.synectiks.cms.graphql.types.Section;

public class RemoveSectionInput {
    private Long sectionId;

    public Long getSectionId() {
        return sectionId;
    }

    public void setSectionId(Long sectionId) {
        this.sectionId = sectionId;
    }
}
