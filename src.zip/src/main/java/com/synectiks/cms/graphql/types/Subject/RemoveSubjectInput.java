package com.synectiks.cms.graphql.types.Subject;

public class RemoveSubjectInput {
    private Long subjectId;

    public Long getSubjectId() {
        return subjectId;
    }

    public void setSubjectId(Long subjectId) {
        this.subjectId = subjectId;
    }
}
