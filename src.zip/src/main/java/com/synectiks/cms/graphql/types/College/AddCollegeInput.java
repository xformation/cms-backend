package com.synectiks.cms.graphql.types.College;

public class AddCollegeInput extends AbstractCollegeInput {
    @Override
    public String toString(){
        return "AddCollegeInput {}" + super.toString();
    }
}
