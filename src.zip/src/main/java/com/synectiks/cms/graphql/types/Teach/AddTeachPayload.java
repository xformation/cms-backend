package com.synectiks.cms.graphql.types.Teach;

import com.synectiks.cms.domain.Teach;

public class AddTeachPayload extends AbstractTeachPayload {
    public AddTeachPayload(Teach teach) {
        super(teach);
    }
}
