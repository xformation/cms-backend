package com.synectiks.cms.graphql.types.Institute;


//import com.synectiks.cms.model.Institute;

public class UpdateInstitutePayload extends AbstractInstitutePayload {
//    public UpdateInstitutePayload(Institute institute) {
//        super(institute);
//    }
}
