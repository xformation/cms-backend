//package com.synectiks.cms.graphql.types.StudentYear;
//
//public class UpdateStudentYearInput extends AbstractStudentYearInput {
//}
