//package com.synectiks.cms.graphql.types.StudentYear;
//
//public class AddStudentYearInput extends AbstractStudentYearInput{
//    @Override
//    public String toString() {
//        return "AddStudentYearInput{}" + super.toString();
//    }
//}
