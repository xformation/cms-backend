package com.synectiks.cms.graphql.types.AcademicYear;

import com.synectiks.cms.domain.AcademicYear;

public class UpdateAcademicYearPayload extends AbstractAcademicYearPayload {
    public UpdateAcademicYearPayload(AcademicYear academicYear){
        super(academicYear);
    }

}
