//package com.synectiks.cms.graphql.types.StudentYear;
//
//import com.synectiks.cms.domain.StudentYear;
//
//public class AddStudentYearPayload  extends AbstractStudentYearPayload{
//    public AddStudentYearPayload(StudentYear studentYear) {
//        super(studentYear);
//    }
//}
