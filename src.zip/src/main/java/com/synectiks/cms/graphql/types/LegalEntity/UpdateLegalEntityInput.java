package com.synectiks.cms.graphql.types.LegalEntity;

public class UpdateLegalEntityInput extends AbstractLegalEntityInput{
}
