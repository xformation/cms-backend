package com.synectiks.cms.graphql.types.LegalEntity;

public class AddLegalEntityInput extends AbstractLegalEntityInput {
    @Override
    public String toString() {
        return "AddLegalEntityInput{}"+ super.toString();
    }
}
