package com.synectiks.cms.graphql.types.Term;

public class RemoveTermInput {
    private Long termId;

    public Long getTermId() {
        return termId;
    }

    public void setTermId(Long termId) {
        this.termId = termId;
    }
}
