package com.synectiks.cms.graphql.types.BankAccounts;

public class AddBankAccountsInput extends AbstractBankAccountsInput {
    @Override
    public String toString() {
        return "AddBankAccountsInput{}" + super.toString();
    }
}
