package com.synectiks.cms.graphql.types.Branch;

public class RemoveBranchInput {
    private Long branchId;

	public Long getBranchId() {
		return branchId;
	}

	public void setBranchId(Long branchId) {
		this.branchId = branchId;
	}

    
}
