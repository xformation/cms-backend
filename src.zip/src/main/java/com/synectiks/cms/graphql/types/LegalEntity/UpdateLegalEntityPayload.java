package com.synectiks.cms.graphql.types.LegalEntity;

import com.synectiks.cms.domain.LegalEntity;

public class UpdateLegalEntityPayload  extends AbstractLegalEntityPayload{
    public UpdateLegalEntityPayload(LegalEntity legalEntity) {
        super(legalEntity);
    }
}
