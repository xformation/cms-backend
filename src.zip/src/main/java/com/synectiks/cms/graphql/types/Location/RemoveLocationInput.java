package com.synectiks.cms.graphql.types.Location;

public class RemoveLocationInput {
    private Long locationId;

    public Long getLocationId() {
        return locationId;
    }

    public void setLocationId(Long locationId) {
        this.locationId = locationId;
    }
}
