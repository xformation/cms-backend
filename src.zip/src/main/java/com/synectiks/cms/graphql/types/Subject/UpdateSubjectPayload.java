package com.synectiks.cms.graphql.types.Subject;

import com.synectiks.cms.domain.Subject;

public class UpdateSubjectPayload extends AbstractSubjectPayload {
    public UpdateSubjectPayload(Subject subject) {
        super(subject);
    }
}
