package com.synectiks.cms.graphql.types.AcademicYear;

public class AddAcademicYearInput extends AbstractAcademicYearInput {
    @Override
    public String toString() {
        return "AddAcademicYearInput{}"+ super.toString();
    }
}
