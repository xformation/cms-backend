package com.synectiks.cms.graphql.types.Holiday;

public class RemoveHolidayInput {
    private Long holidayId;

    public Long getHolidayId() {
        return holidayId;
    }

    public void setHolidayId(Long holidayId) {
        this.holidayId = holidayId;
    }
}
