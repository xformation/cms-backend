package com.synectiks.cms.graphql.types.Student;

public class RemoveStudentInput {
    private Long studentId;

    public Long getStudentId() {
        return studentId;
    }

    public void setStudentId(Long studentId) {
        this.studentId = studentId;
    }
}
