package com.synectiks.cms.graphql.types.Location;

public class UpdateLocationInput extends AbstractLocationInput {
}
