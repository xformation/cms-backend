//package com.synectiks.cms.graphql.types.Semester;
//
//import com.synectiks.cms.domain.Semester;
//
//public class AddSemesterPayload extends AbstractSemesterPayload {
//    public AddSemesterPayload(Semester semester) {
//        super(semester);
//    }
//}
