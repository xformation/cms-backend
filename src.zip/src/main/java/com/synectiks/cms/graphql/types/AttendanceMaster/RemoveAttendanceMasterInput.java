package com.synectiks.cms.graphql.types.AttendanceMaster;

public class RemoveAttendanceMasterInput {
    private Long attendanceMasterId;

	public Long getAttendanceMasterId() {
		return attendanceMasterId;
	}

	public void setAttendanceMasterId(Long attendanceMasterId) {
		this.attendanceMasterId = attendanceMasterId;
	}

    
}
