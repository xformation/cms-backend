package com.synectiks.cms.graphql.types.Term;

import com.synectiks.cms.domain.Term;

public class AddTermPayload extends AbstractTermPayload {

    public AddTermPayload(Term term){
        super(term);
    }
}
