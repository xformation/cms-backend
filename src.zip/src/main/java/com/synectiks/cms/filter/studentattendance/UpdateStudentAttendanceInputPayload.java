package com.synectiks.cms.filter.studentattendance;

public class UpdateStudentAttendanceInputPayload {

	String values;

	public String getValues() {
		return values;
	}

	public void setValues(String values) {
		this.values = values;
	}
	 

	
}
