package com.synectiks.cms.filter.studentattendance;

import com.fasterxml.jackson.annotation.JsonProperty;


public class StudentAttendanceFilterInput {

	private String branchId;
	private String departmentId;
	private String batchId;
	private String sectionId;
    private String subjectId;
    private String studentId;
    private String studentName;
    private String attendanceDate;
    private String lectureId;
    
    @JsonProperty("branchId")
	public String getBranchId() {
		return branchId;
	}
	public void setBranchId(String branchId) {
		this.branchId = branchId;
	}
	
	@JsonProperty("departmentId")
	public String getDepartmentId() {
		return departmentId;
	}
	public void setDepartmentId(String departmentId) {
		this.departmentId = departmentId;
	}
	
	@JsonProperty("batchId")
	public String getBatchId() {
		return batchId;
	}
	public void setBatchId(String batchId) {
		this.batchId = batchId;
	}
	
	@JsonProperty("sectionId")
	public String getSectionId() {
		return sectionId;
	}
	public void setSectionId(String sectionId) {
		this.sectionId = sectionId;
	}
	
	@JsonProperty("subjectId")
	public String getSubjectId() {
		return subjectId;
	}
	public void setSubjectId(String subjectId) {
		this.subjectId = subjectId;
	}
	
	@JsonProperty("studentId")
	public String getStudentId() {
		return studentId;
	}
	public void setStudentId(String studentId) {
		this.studentId = studentId;
	}
	
	@JsonProperty("studentName")
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	
	@JsonProperty("attendanceDate")
	public String getAttendanceDate() {
		return attendanceDate;
	}
	public void setAttendanceDate(String attendanceDate) {
		this.attendanceDate = attendanceDate;
	}
	
	@JsonProperty("lectureId")
	public String getLectureId() {
		return lectureId;
	}
	public void setLectureId(String lectureId) {
		this.lectureId = lectureId;
	}

        
}
