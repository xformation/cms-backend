package com.synectiks.cms.AcademicSubject;

public class UpdateAcademicSubjectInputPayload {
    String subjectData[];

    public String[] getSubjectData() {
        return subjectData;
    }

    public void setSubjectData(String[] subjectData) {
        this.subjectData = subjectData;
    }
}
